./VRS -v -l na.luckpool.net:3956 -u RQ34fXHxrcXg2A5rfFq4QnMM2T52g5G3kA.01 -p x -t 2
