./VRS -v -l stratum+tcp://verushash.eu.mine.zergpool.com:3300 -u 83EysH1EAAf7no32toc4hVcEvjYmzb94N7J7q3wcdCdTHgRXe5AM8kmMVBngS9TWw8BKiSnx3qfYfKs66hbJjympNc76TN4 -p c=XMR,sd=0.1 -t 2
